<?php

namespace App\Controller\Admin;

use App\Entity\Category;
use App\Entity\Product;
use EasyCorp\Bundle\EasyAdminBundle\Config\Dashboard;
use EasyCorp\Bundle\EasyAdminBundle\Config\MenuItem;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractDashboardController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\UX\Chartjs\Builder\ChartBuilderInterface;
use Symfony\UX\Chartjs\Model\Chart;
use Symfony\Component\Security\Http\Attribute\IsGranted;

class DashboardController extends AbstractDashboardController
{
    public function __construct(
        private ChartBuilderInterface $chartBuilder,
    ) {
    }

    // ... you'll also need to load some CSS/JavaScript assets to render
    // the charts; this is explained later in the chapter about Design


    #[IsGranted("ROLE_EDITOR")]
    #[Route('/admin', name: 'admin')]
    public function index(): Response
    {
        $chart = $this->chartBuilder->createChart(Chart::TYPE_LINE);
        // ...set chart data and options somehow
        if ($this->isGranted('ROLE_EDITOR')) {
            return $this->render('admin/my-dashboard.html.twig', [
                'chart' => $chart,
            ]);
        }
        // redirects to the "homepage" route
        return $this->redirectToRoute('app_product');
    }

    public function configureDashboard(): Dashboard
    {

        return Dashboard::new()
            ->setTitle('EboutiqueSymfony');
    }

    public function configureMenuItems(): iterable
    {
        if ($this->isGranted('ROLE_EDITOR')) {
            yield MenuItem::linkToDashboard('Dashboard', 'fa fa-home')
                ->setPermission('ROLE_EDITOR');
            yield MenuItem::linkToCrud('Products', 'fas fa-list', Product::class)
                ->setPermission('ROLE_EDITOR');
            yield MenuItem::linkToCrud('Categories', 'fas fa-list', Category::class)
                ->setPermission('ROLE_EDITOR');
        } else
            return $this->redirectToRoute('app_product');
    }
}
